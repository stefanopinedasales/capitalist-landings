# Weekly Status Report

**Client:** [CLIENT NAME]
**Project:** [PROJECT NAME]
**Week of:** [DATE]
**Prepared by:** [YOUR NAME]

---

## Summary

[1-2 sentence overview: are we on track, ahead, or behind?]

**Overall Status:** 🟢 On Track / 🟡 At Risk / 🔴 Behind

## Completed This Week

- [Task/deliverable completed]
- [Task/deliverable completed]
- [Task/deliverable completed]

## In Progress

| Task | Owner | Status | ETA |
|------|-------|--------|-----|
| [Task] | [Name] | [X]% complete | [Date] |
| [Task] | [Name] | [X]% complete | [Date] |

## Planned Next Week

- [Task/deliverable planned]
- [Task/deliverable planned]
- [Task/deliverable planned]

## Blockers / Risks

| Issue | Impact | Owner | Resolution |
|-------|--------|-------|------------|
| [Blocker] | [High/Med/Low] | [Name] | [What's needed] |

## Action Items

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | [Action item] | [Name] | [Date] |
| 2 | [Action item] | [Name] | [Date] |

## Key Metrics (if applicable)

| Metric | Last Week | This Week | Target |
|--------|-----------|-----------|--------|
| [Metric] | [Value] | [Value] | [Value] |

---

**Next meeting:** [DATE & TIME]

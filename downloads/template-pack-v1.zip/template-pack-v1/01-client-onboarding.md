# Client Onboarding Checklist

**Client:** [CLIENT NAME]
**Project:** [PROJECT NAME]
**Start Date:** [DATE]
**Account Lead:** [YOUR NAME]

---

## Before Kickoff

- [ ] Signed contract / SOW received
- [ ] Payment terms confirmed (deposit invoiced if applicable)
- [ ] Client added to project management tool
- [ ] Shared workspace created (Google Drive / Notion / etc.)
- [ ] Internal team briefed on scope and deliverables

## Kickoff Meeting

- [ ] Introductions — who does what on both sides
- [ ] Walk through SOW scope and deliverables
- [ ] Confirm communication preferences (email / Slack / calls)
- [ ] Agree on meeting cadence (weekly / biweekly)
- [ ] Review timeline and key milestones
- [ ] Identify client-side blockers or dependencies
- [ ] Set expectations for response times

## Access & Credentials

- [ ] Request access to client systems (analytics, CMS, repo, etc.)
- [ ] Credentials stored securely (password manager, not email)
- [ ] Test all access — confirm you can log in

## Post-Kickoff (Within 48 Hours)

- [ ] Send kickoff summary email with notes and action items
- [ ] Create project timeline / Gantt if applicable
- [ ] Schedule recurring status meetings
- [ ] Send first status report template (see `03-weekly-status-report.md`)
- [ ] Begin discovery / first deliverable

## Ongoing

- [ ] Weekly status reports sent on schedule
- [ ] Invoice sent per agreed schedule
- [ ] Monthly check-in on overall satisfaction
- [ ] Document lessons learned for internal improvement

---

**Notes:**
[Add any client-specific notes here]

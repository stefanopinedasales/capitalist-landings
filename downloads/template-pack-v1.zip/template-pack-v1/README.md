# Template Pack v1 — Operations Templates

Thanks for purchasing. This pack contains 8 ready-to-use templates for running a lean business.

## What's Inside

| File | Purpose |
|------|---------|
| `01-client-onboarding.md` | Step-by-step checklist for onboarding new clients |
| `02-statement-of-work.md` | SOW template with scope, timeline, payment terms |
| `03-weekly-status-report.md` | Client-facing weekly update format |
| `04-project-tracker.csv` | Spreadsheet-ready project/task tracker |
| `05-content-calendar.csv` | 30-day content planning spreadsheet |
| `06-meeting-notes.md` | Structured meeting notes with action items |
| `07-invoice.md` | Professional invoice template |
| `08-quarterly-review.md` | QBR template for client or internal review |

## How to Use

- **Markdown files** (.md): Open in any text editor, Notion, Obsidian, or Google Docs. Copy and customize.
- **CSV files** (.csv): Open in Excel, Google Sheets, or Numbers. Headers are pre-set.
- Replace all `[BRACKETED]` placeholders with your info.

## Support

Email support@capitalistengine.ai with your purchase email if you need help.

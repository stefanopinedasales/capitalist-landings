# Meeting Notes

**Date:** [DATE]
**Time:** [TIME]
**Attendees:** [Names]
**Meeting type:** [Kickoff / Status / Planning / Retrospective / Ad-hoc]

---

## Agenda

1. [Topic]
2. [Topic]
3. [Topic]

## Discussion Notes

### [Topic 1]
- [Key point discussed]
- [Decision made]
- [Open question]

### [Topic 2]
- [Key point discussed]
- [Decision made]

### [Topic 3]
- [Key point discussed]

## Decisions Made

| # | Decision | Owner | Date |
|---|----------|-------|------|
| 1 | [Decision] | [Name] | [Date] |
| 2 | [Decision] | [Name] | [Date] |

## Action Items

| # | Action | Owner | Due Date | Status |
|---|--------|-------|----------|--------|
| 1 | [Action] | [Name] | [Date] | Open |
| 2 | [Action] | [Name] | [Date] | Open |
| 3 | [Action] | [Name] | [Date] | Open |

## Parking Lot

- [Topic deferred for later discussion]

---

**Next meeting:** [DATE & TIME]

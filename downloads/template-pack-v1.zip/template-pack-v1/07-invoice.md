# INVOICE

**Invoice #:** [INV-001]
**Date:** [DATE]
**Due Date:** [DATE]

---

**From:**
[YOUR NAME / COMPANY]
[Address Line 1]
[Address Line 2]
[Email]
[Phone]

**Bill To:**
[CLIENT NAME / COMPANY]
[Address Line 1]
[Address Line 2]
[Email]

---

## Services

| # | Description | Qty/Hours | Rate | Amount |
|---|-------------|-----------|------|--------|
| 1 | [Service description] | [X] | $[RATE] | $[AMOUNT] |
| 2 | [Service description] | [X] | $[RATE] | $[AMOUNT] |
| 3 | [Service description] | [X] | $[RATE] | $[AMOUNT] |

---

| | |
|---|---|
| **Subtotal** | $[AMOUNT] |
| **Tax ([X]%)** | $[AMOUNT] |
| **Total Due** | **$[AMOUNT]** |

---

## Payment Details

**Payment method:** [Bank transfer / PayPal / Stripe / Check]

**Bank details (if applicable):**
- Bank: [BANK NAME]
- Account: [ACCOUNT NUMBER]
- Routing: [ROUTING NUMBER]

**PayPal:** [EMAIL]

---

**Terms:** Net [15/30]. Late payments subject to [X]% monthly interest.

Thank you for your business.

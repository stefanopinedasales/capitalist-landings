# Quarterly Business Review

**Quarter:** Q[X] [YEAR]
**Client:** [CLIENT NAME] (or "Internal" for self-review)
**Prepared by:** [YOUR NAME]
**Date:** [DATE]

---

## Executive Summary

[2-3 sentences: How did the quarter go? What were the highlights and lowlights?]

## Key Metrics

| Metric | Q[X-1] | Q[X] | Change | Target |
|--------|--------|------|--------|--------|
| Revenue | $[X] | $[X] | [+/-X%] | $[X] |
| New clients | [X] | [X] | [+/-X] | [X] |
| Retention rate | [X%] | [X%] | [+/-X%] | [X%] |
| [Custom metric] | [X] | [X] | [+/-X] | [X] |

## What Went Well

1. **[Win]** — [Brief explanation of impact]
2. **[Win]** — [Brief explanation of impact]
3. **[Win]** — [Brief explanation of impact]

## What Didn't Go Well

1. **[Issue]** — [What happened and impact]
2. **[Issue]** — [What happened and impact]

## Lessons Learned

- [Specific, actionable lesson]
- [Specific, actionable lesson]

## Goals for Next Quarter

| # | Goal | Metric | Target | Owner |
|---|------|--------|--------|-------|
| 1 | [Goal] | [How you'll measure] | [Target value] | [Name] |
| 2 | [Goal] | [How you'll measure] | [Target value] | [Name] |
| 3 | [Goal] | [How you'll measure] | [Target value] | [Name] |

## Resource Needs

- [Tool / hire / budget needed]
- [Tool / hire / budget needed]

## Risks & Mitigation

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| [Risk] | High/Med/Low | High/Med/Low | [Plan] |
| [Risk] | High/Med/Low | High/Med/Low | [Plan] |

---

**Next review:** Q[X+1] [YEAR]

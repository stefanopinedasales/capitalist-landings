# Statement of Work

**Date:** [DATE]
**Prepared by:** [YOUR NAME / COMPANY]
**Prepared for:** [CLIENT NAME / COMPANY]

---

## 1. Project Overview

[2-3 sentence description of what this project is and why the client needs it.]

## 2. Scope of Work

### In Scope

| # | Deliverable | Description |
|---|-------------|-------------|
| 1 | [Deliverable] | [Brief description] |
| 2 | [Deliverable] | [Brief description] |
| 3 | [Deliverable] | [Brief description] |

### Out of Scope

- [Item explicitly not included]
- [Item explicitly not included]
- [Item explicitly not included]

> Anything not listed in "In Scope" is out of scope. Additional work requires a change order.

## 3. Timeline

| Phase | Deliverable | Duration | Target Date |
|-------|------------|----------|-------------|
| Discovery | Requirements doc | [X] days | [DATE] |
| Build | [Deliverable] | [X] days | [DATE] |
| Review | Client feedback round | [X] days | [DATE] |
| Launch | Final delivery | [X] days | [DATE] |

**Estimated total duration:** [X] weeks

## 4. Client Responsibilities

- Provide [assets / access / feedback] within [X] business days of request
- Designate a single point of contact for approvals
- Delays in client deliverables may shift the timeline

## 5. Pricing & Payment

| Item | Amount |
|------|--------|
| Total project fee | $[AMOUNT] |
| Deposit (due on signing) | $[AMOUNT] ([X]%) |
| Milestone payment | $[AMOUNT] (on [MILESTONE]) |
| Final payment | $[AMOUNT] (on delivery) |

**Payment terms:** Net [15/30] from invoice date.
**Late payment:** [X]% monthly interest on overdue balances.

## 6. Change Orders

Any work outside the defined scope requires a written change order with updated pricing and timeline, approved by both parties before work begins.

## 7. Termination

Either party may terminate with [14/30] days written notice. Client pays for all work completed to date.

## 8. Acceptance

| | Name | Signature | Date |
|---|------|-----------|------|
| **Provider** | [YOUR NAME] | _______________ | [DATE] |
| **Client** | [CLIENT NAME] | _______________ | [DATE] |
